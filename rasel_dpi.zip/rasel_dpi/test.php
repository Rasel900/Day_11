<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
<div class="one">
Welcome

<h1>Welcome to php </h1>
<?php
    echo "This is my first program in php";


?>
</div>
<div class="two">
    <h1>DPI</h1>
</div>
<hr>


        <?php
            
            $num1 =100;
            $num2 = "100";
            $result = $num1+$num2;

        ?>

<div class="tree">
<?php

        
    echo 'This is maltipication= ' .$result;

    if($num1===$num2){
        echo "<br> true";
    }
    else{
        echo " <br> false";
    }

    var_dump($num2)
    ?>

</div>
</body>
</html>